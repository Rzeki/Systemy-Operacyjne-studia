#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <string.h>
#include <sys/wait.h>

#define ROZ 256 //Maksymalny rozmiar tablicy message
#define POR 5 //zdefiniowana stala porcja danych

int main(int argc,char* argv[])
{
    int fd2,desk;
    char message[ROZ]; //definicja tablicy na wiadomosc
    char* mypipe = argv[1]; //nazwa potoku przekazana przez main.c
    int buff; //zmienna przyjmujaca to co zwraca read (liczbe przeczytanych bajtow)
    fd2=open(mypipe,O_RDONLY,0666); //otworzenie potoku
    if(fd2==-1)
    {
        perror("open() error"); //zabezpieczenie open()
        exit(EXIT_FAILURE);
    }
    desk=open("output.txt",O_WRONLY | O_CREAT,0666); //otworzenie pliku tekstowego
    if(desk==-1)
    {
        perror("open() failed"); //zabezpieczenie open()
        exit(EXIT_FAILURE);
    }
    while((buff=read(fd2,message,POR))>0) //czytanie do czasu az potok bedzie pusty
    {
        if(buff==-1)
        {
            perror("read error"); //zabezpieczenie read
            exit(EXIT_FAILURE);
        }
        if((write(1,"\n    Przyjalem fragment tekstu i wysylam go do pliku:\n",55))==-1) //informacja o przyjeciu fragmentu przez proces macierzysty
        {
            perror("write error"); //zabezpieczenie write
            exit(EXIT_FAILURE);
        }
        if((write(1,message,buff))==-1)    //dodalem tab, aby wyroznic wiadomosc o przyjeciu
        {
            perror("write error"); //zabezpieczenie write
            exit(EXIT_FAILURE);
        }
        if((write(desk,message,buff))==-1)  //wpisywanie do pliku output.txt takiej samej porcji bajtow co zwraca read()
        {
            perror("write error"); //zabezpieczenie write
            exit(EXIT_FAILURE);
        }
        sleep((rand()%5)+1);
    }
    if(write(1,"\nTowar zostal wyslany i odebrany w calosci!\n",45)==-1)
        {
            perror("write error"); //zabezpieczenie write
            exit(EXIT_FAILURE);
        }
    if((close(fd2))==-1)
    {
        perror("close error"); //zabezpieczenia close
        exit(EXIT_FAILURE);
    }
    if((close(desk))==-1)
    {
        perror("close error");
        exit(EXIT_FAILURE);
    }

    return 0;
}