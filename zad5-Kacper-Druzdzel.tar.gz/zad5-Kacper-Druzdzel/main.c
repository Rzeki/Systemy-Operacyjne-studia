#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <string.h>
#include <sys/wait.h>

int main(int argc, char* argv[])  //argv[1] - nazwa potoku  , argv[2] - nazwa pliku tekstowego z ktorego czytamy
{
    if(argc!=3)
    {
        perror("Wrong amount of arguments");  //sprawdzenie liczby argumentow
        exit(EXIT_FAILURE);
    }

    char* mypipe = argv[1];  //nazwa potoku
    char* textfile = argv[2]; //nazwa pliku tekstowego z ktorego czytamy

    if((mkfifo(mypipe,0666))==-1) // prawa read i write dla każdej grupy
    {
        perror("mkfifo error");   //zabezpieczenie mkfifo()
        exit(EXIT_FAILURE);
    }

    int prod_pid,kons_pid;  //pidy dwoch oddzielnych forkow, wywolane oddzielnie poniewaz uruchamiaja inne programy

    switch(prod_pid=fork()) // producent
    {
        case -1:
            perror("fork error"); // zabezpieczenie fork()
            exit(EXIT_FAILURE);
        break;

        case 0:
            execl("./producent.x","producent.x",mypipe,textfile,NULL); //w programie producent.c argv[0]="producent.x" , argv[1]=(wprowadzona nazwa potoku), argv[2]=(wprowadzona nazwa pliku tekstowego)
            perror("execl failed");     //zabezpieczenie execl
            exit(EXIT_FAILURE);
        break;

        default:
        break; //proces macierzysty pomija switch
    }

    switch(kons_pid=fork()) // konsument
    {
        case -1:
            perror("fork error"); //zabezpieczenie fork()
            exit(EXIT_FAILURE);
        break;

        case 0:
            execl("./konsument.x","konsument.x",mypipe,NULL); //podobnie jak u producenta z ta roznica ze przekazujemy tylko nazwe programu oraz nazwe potoku poniewaz nie uzywamy nigdzie juz nazwy pierwszego pliku tekstowego
            perror("execl failed"); //zabezpieczenie execl
            exit(EXIT_FAILURE);
        break;

        default:
        break; //tak samo jak u producenta proces macierzysty pomija switch
    }

    
    if((wait(NULL))==-1) //czekanie na procesy potomne
    {
        perror("wait error"); //zabezpieczenie wait
        exit(EXIT_FAILURE);
    }
    if((wait(NULL))==-1)
    {
        perror("wait error");
        exit(EXIT_FAILURE);
    }
    if((unlink(mypipe))==-1)  //usuwanie potoku
    {
        perror("unlink error");
        exit(EXIT_FAILURE);
    }
    return 0;
}