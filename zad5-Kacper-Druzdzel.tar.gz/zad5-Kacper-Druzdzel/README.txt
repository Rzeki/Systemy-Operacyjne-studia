Szanowny Panie Profesorze,
Oddaje do oceny programy konsument.c , producent.c , main.c , makefile oraz tekst1.txt (plik tekstowy z przykladem)

Dzialanie:

main.c:
Jest to glowny program potrzebny do podpunktu a), tworzy on najpierw potok a nastepnie uruchamia za pomoca execl program konsument.c oraz producent.c, a nastepnie czeka on na ich zakonczenie za pomoca funkcji wait.

producent.c:
Otwiera on potok i plik tekstowy a nastepnie czyta on z pliku tekst1.txt oraz wysyla prosto do potoku (taka sama porcja bitow co zwraca read() ), po wyslaniu zamyka 
plik tekstowy oraz potok.

konsument.c:
Tak samo jak w producent.c na poczatku nastepuje otwarcie potoku i utworzenie pliku do ktorego bedzie wpisywane dane z potoku. Nastepnie czyta dane przekazane przez
producenta i kieruje je prosto do utworzonego pliku tekstowego (taka sama porcja bitow co zwraca read() ), tak powstaje plik tekstowy o domyslnej nazwie output.txt

Makefile:

Dostepne polecenia: run , all , rem , clean , tar , check , run_prod , run_kons , createpipe , deletepipe , run_b

UWAGA! Co do parametrow to wszystkie programy pobieraja parametry wg. wzoru:

./[nazwa programu].x [nazwa potoku] [nazwa pliku tekstowego z ktorego bedziemy czytac]


run:
uruchamia main.c  (./main.x named_pipe tekst1.txt)   (przykladowe parametry)

all:
kompiluje wszystko (main.c , producent.c , konsument.c)

rem:
usuwa output.txt (poniewaz jest on generowany przy wywolaniu programu dzieki fladze O_CREAT)

clean:
czysci pliki binarne

tar:
kompresuje i archiwizuje caly folder z zadaniem

check:
porownuje pliki tekstowe tekst1.txt oraz output.txt za pomoca diff -s

run_prod:
uruchamia program producent.c za pomoca xterm (z przykladowymi parametrami: named_pipe , tekst1.txt)

run_kons:
uruchamia program konsument.c za pomoca xterm (z przykladowymi parametrami: named_pipe , tekst1.txt)

createpipe:
tworzy potok w terminalu za pomoca mkfifo

deletepipe:
usuwa potok z poziomu powloki za pomoca unlink

run_b:
wszystkie komendy potrzebne do uruchomienia podpunktu b)
(w kolejnosci: createpipe run_prod run_kons deletepipe)


z powazaniem
Kacper Druzdzel



