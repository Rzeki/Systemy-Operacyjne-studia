#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <string.h>
#include <sys/wait.h>

#define ROZ 256 //Maksymalny rozmiar tablicy message
#define POR 5 //zdefiniowana stala porcja danych

int main(int argc,char* argv[])
{
    sleep(3); //czekanie na gotowosc w odbieraniu konsumenta
    int fd1,desk;
    char* mypipe = argv[1]; //(nazwa potoku przekazana w main.c)
    char* textfile = argv[2]; //(nazwa pliku tekstowego przekazana w main.c)
    char message[ROZ];  //definicja tablicy na wiadomosc
    int buff;
    fd1=open(mypipe,O_WRONLY,0666); //otwieranie potoku (prawa read i write dla wszystkich grup)
    if(fd1==-1)
    {
        perror("open() error"); //zabezpieczenie open()
        exit(EXIT_FAILURE);
    }
    desk=open(textfile,O_RDONLY,0666); //otwieranie pliku tekstowego
    if(desk==-1)
    {
        perror("open() failed"); //zabezpieczenie open()
        exit(EXIT_FAILURE);
    }
    while((buff=read(desk,message,POR))>0)  //wczytywanie do momentu az plik tekstowy bedzie pusty (tym razem stala porcja bitow)
    {
        if(buff==-1)
        {
            perror("read error"); //zabezpieczenie read
            exit(EXIT_FAILURE);
        }
        if((write(1,"\nSczytuje fragment tekstu i wysylam go do pliku:\n",50))==-1)
        {
            perror("write error"); //zabezpieczenie write
            exit(EXIT_FAILURE);
        }
        if((write(1,message,buff))==-1)
        {
            perror("write error"); //zabezpieczenie write
            exit(EXIT_FAILURE);
        }
        if((write(fd1,message,buff))==-1)  //wpisuje stala liczbe bitow zwracana przez read
        {
            perror("write error"); //zabezpieczenie write
            exit(EXIT_FAILURE);
        }
        sleep((rand()%5)+1);
    }
    if((close(fd1))==-1)
    {
        perror("close error"); //zabezpieczenia close
        exit(EXIT_FAILURE);
    }
    if((close(desk))==-1)
    {
        perror("close error");
        exit(EXIT_FAILURE);
    }

    return 0;
}