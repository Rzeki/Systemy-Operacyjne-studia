Szanowny Panie Profesorze,
Zastosowalem sie do uwag związanych z ostatnim zadaniem, myślę że teraz nie będzie żadnych problemów.

Pełny katalog składa się z następujących plików: glowny.c , funkcja.c , MAKEFILE , README.txt

-Opisy

glowny.c
Podobnie jak w zadaniu 1b mamy pętlę for która uruchamia fork
tylko tym razem wyświetlaniem poszczególnych ID procesów zajmuje się funkcja execv()
powoduje ona zastąpienie obecnego procesu wskazanym w parametrach oraz powoduje zakończenie całego procesu po jego wykonaniu.

funkcja.c
Program który wypisuje poszczególne ID obecnego procesu za pomocą funkcji, którą wywołuje w main().

MAKEFILE
dostępne polecenia:

make all    //tworzy glowny.x oraz funkcja.x
make run    //uruchamia program glowny.x
make clean  //czyści katalog z plików binarnych
make c_run  //compile run komenda dla czystej wygody, kompiluje wszystko (all) a następnie uruchamia (run) 
make tar  //tworzy skompresowaną wersję folderu z ćwiczeniem


ODPOWIEDŹ
Przy n-krotnym wywołaniu funkcji fork-exec powstanie n procesów (nie licząc macierzystego), ponieważ jak wyżej wspomniałem execv sprawia że po wykonaniu
programu który uruchamia "popełnia samobójstwo", czyli fork() nie wykona się po raz kolejny w procesach-dzieciach.



Z poważaniem
Kacper Drużdżel
