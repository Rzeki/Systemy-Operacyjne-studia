#include <stdio.h>
#include <sys/types.h> 
#include <stdlib.h>
#include <unistd.h> 
#include <sys/wait.h>

void GetInfo()
{
    printf("UID: %d\nGID: %d\nPID: %d\nPPID: %d\nPGID: %d\n\n",getuid(),getgid(),getpid(),getppid(),getpgid(getpid()));  //wypisanie poszczegolnych ID procesu
}

int main(int argc, char* argv[])
{
    GetInfo();    //wywolanie funkcji w mainie
    return 0;
}
