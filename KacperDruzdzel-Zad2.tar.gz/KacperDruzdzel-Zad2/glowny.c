#include <stdio.h> 
#include <stdlib.h>  //potrzebne do funkcji exit (inaczej wystepuje ostrzezenie)
#include <sys/types.h> 
#include <unistd.h> 
#include <sys/wait.h> 

int main(int argc, char* argv[])
{
    // w tym programie tablica argv bedzie miala postac (./glowny.x , funkcja.x , NULL) || argv ma w domysle wlacnosc: (argv[argc]=NULL)
    printf("Proces macierzysty\n");
    printf("UID: %d\nGID: %d\nPID: %d\nPPID: %d\nPGID: %d\n\n",getuid(),getgid(),getpid(),getppid(),getpgid(getpid()));
    //ID procesu macierzystego trzeba wypisac printf poniewaz gdybysmy to zrobili execv to reszta programu nie wykonalaby sie
    int i;
    for(i=0;i<3;i++)
    {
       switch (fork())
        {
            case -1:
                perror("fork error");  //gdyby fork() sie nie powiodl
                exit(1);
            case 0:
                printf("Proces dziecko\n");
                execv(argv[1],argv);   //w tym przypadku argv[1]="funkcja.x" (czyli to co jest wpisane po ./glowny.x podczas uruchamiania) || do funkcja.c przekazujemy argv[], lecz akurat w tym programie nic nie robimy z tymi parametrami
                perror("fork error");  //wstawienie perrora tutaj powoduje to jezeli wykonanie execv() sie nie powiedzie to zwroci -1 i program wyrzuci blad
                exit(1);
            default:
                wait(0);
        };
    }
    return 0;
}
