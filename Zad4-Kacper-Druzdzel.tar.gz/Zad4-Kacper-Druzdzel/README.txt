Szanowny Panie Profesorze,
Oddaje zadania program.c, towar.txt, Makefile oraz utworzony po uruchomieniu programu (program.c) towar-u-konsumenta.txt


Dzialanie program.c
Na poczatku programu zdefiniowalem wszystko co jest potrzebne do otworzenia potoku, nastepnie program za pomoca fork() tworzy pojedynczy proces potomny w tym przypadku
bedzie to producent, a proces potomny bedzie konsumentem. Producent sczytuje w petli fragmenty tekstu (w tym przypadki po 5 znakow) oraz jeszcze w petli wysyla je do 
procesu macierzystego, ktorzy sczytuje je i wysyla do pliku takim samym sposobem. Prosze wybaczyc nieczytelnosc w terminalu, w pliku towar.txt umiescilem znaki konca linii, ktore psuja wyswietlanie w terminalu, staralem sie wyroznic wysylane i odbierane fragmenty wiec przy odebraniu umiescilem tab. Jak w poleceniu sleep jest ustawiony na losowa liczbe z zakresu 1-5, przy pomocy rand().

Makefile:
dostepne komendy: run all rem clean tar check

run:
uruchamia program.c  (./program.x)

all:
kompiluje wszystko, w tym przypadku tylko program.c

rem:
usuwa towar-u-konsumenta.txt (poniewaz jest on generowany przy wywolaniu programu dzieki fladze O_CREAT)

clean:
czysci pliki binarne

tar:
kompresuje i archiwizuje caly folder z zadaniem

check:
porownuje pliki tekstowe towar.txt oraz towar-u-konsumenta.txt za pomoca diff -s



z powazaniem i zyczeniami zdrowia,
Kacper Druzdzel


