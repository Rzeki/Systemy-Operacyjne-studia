#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <string.h>
#include <sys/wait.h>

#define MSG_SIZE 512 //maksymalny rozmiar wiadomosci

int main(int argc, char* argv[])
{
    int pid;            //przechowuje pid z forka
    int mypipe[2];    //deklaracja "koncow" pipe()
    char message[MSG_SIZE]="";  //bufor osobno dla producenta i konsumenta
    char napis[MSG_SIZE]="";
    
    
    if(pipe(mypipe) == -1)   //zabezpieczenie pipe()
    {
        perror("pipe error");
        exit(EXIT_FAILURE);
    }
    int desk,desk2;  //zmienne ktorym przypisuje deskryptory otwieranych plikow
    pid=fork();
    switch(pid)
    {
        case -1:
            perror("fork error");  //zabezpieczenie funkcji fork()
            exit(EXIT_FAILURE);
        break;

        case 0:
            //producent
            if((close(mypipe[0]))==-1) //w potomnym nie uzywamy mypipe[0] wiec zamykam
            {
                perror("close() error");
                exit(EXIT_FAILURE);
            }
            if((desk=open("towar.txt",O_RDONLY,0666))==-1) // prawa dostepu read-write dla uzytkownika/grupy/innych
            {
                perror("open() error");
                exit(EXIT_FAILURE);
            }
            while((read(desk,message,5))>0)  //sczytywanie z pliku fragmentu tekstu do czasu az sczyta wszystko
            {
                write(1,"\nSczytuje fragment tekstu i wysylam go do pliku:\n",50);
                write(1,message,5);
                if((write(mypipe[1],message,5))==-1)  //w tej samej petli wysylam fragment tekstu do procesu macierzystego
                {
                    perror("write error");
                    exit(EXIT_FAILURE);
                }
                sleep((rand()%5)+1);   //losowanie liczby z zakresu 1-5 
            }
            if((close(desk))==-1)
            {
                perror("close() error");
                exit(EXIT_FAILURE);
            }
            if((close(mypipe[1]))==-1) //po ukonczeniu pracy "sprzatam" za pomoca close()
            {
                perror("close() error");
                exit(EXIT_FAILURE);
            }
        break;

        default:
            //konsument
            sleep(1); //konsument czeka na utworzenie pierwszego write
            if((close(mypipe[1]))==-1)  //nie uzywamy tutaj mypipe[1] dlatego zamykam
            {
                perror("close() error");
                exit(EXIT_FAILURE);
            }
            if((desk2=open("towar-u-konsumenta.txt",O_WRONLY|O_CREAT,0666))==-1)
            {
                perror("open() error");
                exit(EXIT_FAILURE);
            }  
            while((read(mypipe[0],napis,5))>0)  //tutaj rowniez czyta az do momentu, gdy sczyta wszystko
            {
                write(1,"\n    Przyjalem fragment tekstu i wysylam go do pliku:\n",55); //informacja o przyjeciu fragmentu przez proces macierzysty
                write(1,napis,5);    //dodalem tab, aby wyroznic wiadomosc o przyjeciu
                if((write(desk2,napis,5))==-1)   
                {
                    perror("write error");
                    exit(EXIT_FAILURE);
                }
                sleep((rand()%4)+1);  //losowanie z zakresu 1-5 j.w.
            }
            if((close(mypipe[0]))==-1)
            {
                perror("close() error");
                exit(EXIT_FAILURE);
            }
            if((close(desk2))==-1)  //to samo co w procesie potomnym
            {
                perror("close() error");
                exit(EXIT_FAILURE);
            }
            if((wait(NULL))==-1)  //proces macierzysty czeka na zakonczenie procesu potomnego
            {
                perror("wait() error");
                exit(EXIT_FAILURE);
            }
            if(write(1,"\nTowar zostal wyslany i odebrany w calosci!\n",45)==-1)
            {
                perror("write error");
                exit(EXIT_FAILURE);
            }
        break;
    }
    return 0;
}