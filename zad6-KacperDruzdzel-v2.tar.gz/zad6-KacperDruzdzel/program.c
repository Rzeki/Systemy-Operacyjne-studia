#include "semafor.h"
#include <semaphore.h>
#include <stdlib.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <unistd.h>

#define BUF 10


int main(int argc, char* argv[])
{
    sem_t *S;
    S = S_Open("/przyklad");  //otworzenie semafora
    S_Info(S);
    int num = atoi(argv[1]); //parametr ilosc wykonan sekcji krytycznej przekazane przez execl
    int file,buf,inkrem; 
    char message[BUF]=""; //bufor na odczytywanie z pliku
    char mes[BUF]=""; //bufor na zapis do pliku

    
    
    
    for(int i=0;i<num;i++)
    {
        //---------------------------------------------------------------------------------------------------------------------------
        sleep((rand()%2)+1); //uspienie na czas 1-2 sek
        if((write(1,"Oczekiwanie na sekcje krytyczna\n",33))==-1)
        {
            perror("write() error"); //zabezpieczenie write
            exit(EXIT_FAILURE);
        }
        if((write(1,"   ",4))==-1)  //odstep dla sekcji krytycznej przed wyswietleniem wartosci semafora
        {
            perror("write() error"); //zabezpieczenie write
            exit(EXIT_FAILURE);
        }
        S_Info(S);

        S_P(S); //opuszczenie semafora

        if((write(1,"   ",4))==-1)  //odstep dla sekcji krytycznej przed wyswietleniem wartosci semafora
        {
            perror("write() error"); //zabezpieczenie write
            exit(EXIT_FAILURE);
        }
        S_Info(S);
        // sekcja krytyczna ---------------------------------------------------------------------------------------------------------
        if((write(1,"   Proces jest w sekcji krytycznej\n",36))==-1)
        {
            perror("write() error"); //zabezpieczenie write
            exit(EXIT_FAILURE);
        }
        file = open("numer.txt",O_RDONLY,0666); //otworzenie pliku numer.txt (read)
        if(file==-1)
        {
            perror("open() error"); //zabezpieczenie open
            exit(EXIT_FAILURE);
        }
        while((buf=read(file,message,5))>0) //czytanie z pliku numer.txt
        {
            if((write(1,"   Z pliku zczytano liczbe: ",29))==-1)
            {
                perror("write() error"); //zabezpieczenie write
                exit(EXIT_FAILURE);
            }
            if((write(1,message,buf))==-1)
            {
                perror("write() error"); //zabezpieczenie write
                exit(EXIT_FAILURE);
            }
            if((write(1,"\n",2))==-1)
            {
                perror("write() error"); //zabezpieczenie write
                exit(EXIT_FAILURE);
            }
        }
        if((close(file))==-1) //zamkniecie pliku
        {
            perror("close() error"); //zabezpieczenie close
            exit(EXIT_FAILURE);
        }
        inkrem=atoi(message);  //zamiana i inkrementacja liczby z pliku
        inkrem++;
        file = open("numer.txt",O_TRUNC | O_WRONLY,0666); //ponowne otworzenie pliku z wyczyszczeniem zawartości
        if(file==-1)
        {
            perror("open() error"); //zabezpieczenie open
            exit(EXIT_FAILURE);
        }
        if((sprintf(mes,"%d",inkrem))<0) // zamiana int na char
        {
            perror("sprintf() error"); //zabezpieczenie sprintf
            exit(EXIT_FAILURE);
        }
        sleep((rand()%3)+1);
        if((write(1,"   wpisuje liczbe: ",20))==-1)
        {
            perror("write() error"); //zabezpieczenie write
            exit(EXIT_FAILURE);
        }
        if((write(1,mes,ile_cyfr(inkrem)))==-1)
        {
            perror("write() error"); //zabezpieczenie write
            exit(EXIT_FAILURE);
        }
        if((write(1,"\n",2))==-1)
        {
            perror("write() error"); //zabezpieczenie write
            exit(EXIT_FAILURE);
        }
        if((write(file,mes,ile_cyfr(inkrem)))==-1)  //wpisanie liczby do pliku numer.txt
        {
            perror("write() error"); //zabezpieczenie write
            exit(EXIT_FAILURE);
        }
        if((close(file))==-1)  //zamkniecie pliku
        {
            perror("close() error"); //zabezpieczenie close
            exit(EXIT_FAILURE);
        }
        sleep((rand()%2)+1);        
        //opuszczenie sekcji krytycznej ----------------------------------------------------------------------------------------
        if((write(1,"   ",4))==-1) //odstep dla wartosci semafora
        {
            perror("write() error"); //zabezpieczenie write
            exit(EXIT_FAILURE);
        }
        S_Info(S);

        S_V(S); //podniesienie semafora

        if((write(1,"   ",4))==-1)
        {
            perror("write() error"); //zabezpieczenie write
            exit(EXIT_FAILURE);
        }
        S_Info(S);
        if((write(1,"Proces opuscil sekcje krytyczna\n",33))==-1)
        {
            perror("write() error"); //zabezpieczenie write
            exit(EXIT_FAILURE); 
        }   
        
    //--------------------------------------------------------------------------------------------------------------------------------
    }
    S_Close(S); //zamkniecie semafora

    return 0;
}
