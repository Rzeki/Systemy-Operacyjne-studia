#include "semafor.h"
#include <semaphore.h>
#include <stdlib.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <unistd.h>
#include <sys/wait.h>

int main(int argc, char* argv[])
{
    int file;
    file = open("numer.txt",O_WRONLY | O_CREAT,0666);  //utworzenie i wpisanie 0 do pliku tekstowego
    if(file==-1)
    {
        perror("open() error"); //zabezpieczenie open
        exit(EXIT_FAILURE);
    }
    if((write(file,"0",1))==-1)
    {
        perror("write() error"); //zabezpieczenie write
        exit(EXIT_FAILURE);
    }
    if((close(file))==-1)
    {
        perror("close() error"); //zabezpieczenie close
        exit(EXIT_FAILURE);
    }
    int num = atoi(argv[2]); //ile razy fork zostanie wywolany
    int val=1; //wartosc z jaka tworze semafor
    sem_t *S;
    S = S_Create("/przyklad",val); //otworzenie semafora i nadanie mu wartosci 1  || funkcja S_Create posiada juz zabezpieczenie bledow w sobie
    if((write(1,"Semafor utworzony z wartoscia ",30))==-1)
        {
            perror("write() error"); //zabezpieczenie write
            exit(EXIT_FAILURE);
        }
    char BB[10];
    if((sprintf(BB,"%d",val))<0)
        {
            perror("sprintf() error"); //zabezpieczenie sprintf
            exit(EXIT_FAILURE);
        }
    if((write(1,BB,ile_cyfr(val)))==-1)
        {
            perror("write() error"); //zabezpieczenie write
            exit(EXIT_FAILURE);
        }
    if((write(1," oraz adresem ",14))==-1)
        {
            perror("write() error"); //zabezpieczenie write
            exit(EXIT_FAILURE);
        }
    char bufor_2[20];
    int g=sprintf(bufor_2,"%p",&S); //%p stosowany jest przy wyświetlaniu adresow
    if(g<0)
    {
        perror("sprintf() error");
        exit(EXIT_FAILURE);
    }
    if((write(1,bufor_2,g))==-1)
    {
        perror("write() error"); //zabezpieczenie write
        exit(EXIT_FAILURE);
    }
    if((write(1,"\n",2))==-1)
    {
        perror("write() error"); //zabezpieczenie write
        exit(EXIT_FAILURE);
    }
    
    int zmienna;

    for(int i=0;i<num;i++)
    {
        zmienna=fork();
        switch(zmienna)
        {
            case -1:
                perror("fork error"); //zabezpieczenie forka
                exit(EXIT_FAILURE);
            break;

            case 0:
                execl(argv[1],argv[1],argv[3],NULL); //przekazuje nazwe programu do uruchomienia oraz ilosc wykonan sekcji krytycznej (argv[3])
                perror("exec error"); //zabezpieczenie exec
                exit(EXIT_FAILURE);
            break;

            default:
            break;  //dla macierzystego nastepuje wyjscie i oczekiwanie na procesy potomne
        }
    }
    for(int j=0;j<num;j++)  //oczekiwanie na wszystkie procesy potomne
    {
        wait(NULL);
    }

    S_Remove("/przyklad");  //usuniecie semafora
    
    return 0;
}
