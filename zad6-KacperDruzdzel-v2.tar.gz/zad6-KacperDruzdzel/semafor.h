#ifndef SEMAPHORE_H
#define SEMAPHORE_H
#include <semaphore.h>
#include <stdlib.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <unistd.h>

sem_t *S_Create(const char *S_name,int value); //poszczegolne funkcje opisane sa w semafor.c
sem_t *S_Open(const char *S_name);
void S_P(sem_t *S);
void S_V(sem_t *S);
void S_Info(sem_t *S);
void S_Remove(const char *S_name);
void S_Close(sem_t *S);
int ile_cyfr(int a);

#endif