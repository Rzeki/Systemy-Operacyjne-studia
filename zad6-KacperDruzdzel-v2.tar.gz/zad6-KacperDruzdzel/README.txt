Szanowny Panie Profesorze,
Oddaje do oceny pliki powielacz.c, program.c, semafor.c, semafor.h, Makefile oraz README, numer.txt(powstaly po wywolaniu programu)

Opis dzialania programu:
Glownym programem jest tutaj powielacz.c ktory otwiera semafor nadaje mu wartosc oraz tworzy za pomoca forka procesy potomne w ktorych uzywany jest execl
(przekazuje on nazwe wykowanego programu w miejsce argv[0] oraz liczbe wykonan sekcji krytycznej do argv[1]), ktory uruchamia program.x, w ktorym nastepuje otworzenie semafora oraz odpowiednie jego opuszczanie i podnoszenie oraz wykonywanie w sekcji krytycznej pobrania liczby z pliku zamiany jej na int, inkrementacji, zamiany na char oraz wpisania do pliku numer.txt, na koniec semafor zostaje zamkniety, po wykonaniu wszystkich procesow potomnych proces macierzysty usuwa semafor (proces macierzysty oczekuje na zakonczenie przez wait() ).


Makefile:

make all
tworzy wszystkie potrzebne pliki binarne do uruchomienia programu

make rem
usuwa plik numer.txt (jest on tworzony przy uruchomieniu programu)

make run
uruchamia program (./powielacz.x ./program.x 3 2)
z przykladowymi parametrami petla z fork() wykona sie 3 razy, a sekcja krytyczna wykona sie 2 razy w kazdym z dzieci.

make tar
kompresuje folder z zadaniem

make clean
usuwa pliki binarne

Ostatecznie w numer.txt powinnismy dostac 2*3=6 (oczywiscie w tym przykladzie)

Bez sekcji krytycznej numer pozostaje bez zmian.

z powazaniem i zyczeniami zdrowia
Kacper Druzdzel


