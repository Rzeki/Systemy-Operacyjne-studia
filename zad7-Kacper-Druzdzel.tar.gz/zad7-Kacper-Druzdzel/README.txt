Szanowny Panie Profesorze,
Oddaje do oceny pliki main.c, konsument.c, semafor.c, semafor.h, sharmem.c, sharmem.h, input.txt, producent.c, Makefile oraz README, output.txt(powstaly po wywolaniu programu)

Opis dzialania programu:
na poczatku uruchamiany jest main.c gdzie tworzone sa 2 semafory dla producenta i konsumenta oraz obszar pamieci dzielonej, nastepnie poprzez fork() uruchamiane sa
procesy konsumenta oraz producenta i przekazuje sie im nazwy semaforow, pamieci dzielonej oraz plikow wejscia i wyjscia. Proces macierzysty nastepnie czeka na zakonczenie procesow potomnych i usuwa semafory i pamiec dzielona.

producent.c
tworzy on towar - otwierany jest w nim plik wejscia, semafory oraz pamiec dzielona, ktora jest rowniez mapowana w nastepnym kroku. Nastepnie w petli while rozpoczyna sie czytanie do bufora, opuszczenie semafora producenta oraz wstawianie porcji danych do pamieci dzielonej, z ktorej nastepnie konsument bedzie czytal. Na koniec po wykonaniu wszystkich instrukcji semafory,pamiec dzielona oraz plik wejscia sa zamykane.

konsument.c
podobnie jak w producencie otwierane sa semafory oraz pamiec dzielona oraz wykonane zostaje mapowanie. Nastepnie w petli while nastepuje czytanie i wpisywanie znak po znaku do pliku wyjscia. Informacja o zakonczeniu pracy dla konsumenta jest pojawienie sie 0 na koncu wpisanego tekstu. Po wpisaniu wszystkiego z pamieci dzielonej do pliku podobnie jak w producencie nastepuje zamkniecie semaforow oraz pamieci dzielonej.


Makefile:

make runs1
uruchomienie main z biblioteka statyczna

make rund1
uruchomienie main z bibliotyka dynamiczna (sposob 1)

make rund2
uruchomienie main z bibliotyka dynamiczna (sposob 2)

make diff
sprawdza pliki wejscia i wyjscia

make tar
kompresuje folder z zadaniem

make clean
usuwa pliki binarne, biblioteki oraz output.txt

(makefile glownie robiony na podstawie przykladu z StartSO, jedyna zmiana jaka przeczytalem jest to ze najlepiej jak flaga -lrt jest na samym koncu i rzeczywiscie zrobilo to roznice)

z powazaniem i zyczeniami zdrowia
Kacper Druzdzel
