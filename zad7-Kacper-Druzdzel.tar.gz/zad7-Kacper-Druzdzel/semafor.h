#ifndef SEMAPHORE_H
#define SEMAPHORE_H
#include <semaphore.h>
#include <stdlib.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <unistd.h>
#include <sys/wait.h>
#include <string.h>

#define SEM_KONS "/sem-konsument"
#define SEM_PROD "/sem-producent"


sem_t *S_Create(const char *S_name,int value); //poszczegolne funkcje opisane sa w semafor.c
sem_t *S_Open(const char *S_name); //otwarcie semafora
void S_P(sem_t *S); //opuszczenie semafora
void S_V(sem_t *S); //podniesienie semafora
void S_Info_P(sem_t *S); //wartosci semaforow
void S_Info_K(sem_t *S);
void S_Remove(const char *S_name); //usuniecie semafora (unlink)
void S_Close(sem_t *S); //zamkniecie semafora
int ile_cyfr(int a);



#endif