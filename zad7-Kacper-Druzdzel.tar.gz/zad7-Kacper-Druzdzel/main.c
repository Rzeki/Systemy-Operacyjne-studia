#include "semafor.h"
#include "sharmem.h"


int main(int argc, char* argv[])
{
    int shar_mem_fd = Sharmem_create(SHM_NAME, sizeof(SegmentPD)); //tworzenie obszaru pamięci dzielonej
    S_Create(SEM_PROD,NBUF); //stworzenie semafora producenta i nadanie mu wartosci 5
    S_Create(SEM_KONS,0); //stworzenie semafora konsumenta i nadanie mu wartosci 0


    int prod_fork,kons_fork; //zmienne fork()
    switch(prod_fork=fork())
    {
        case -1:
        perror("fork error"); //zabezpieczenie fork()
        exit(EXIT_FAILURE);
        break;

        case 0:
        execl("./producent.x","producent.x",SEM_PROD,SEM_KONS,SHM_NAME,IN_FILE,OUT_FILE,NULL); //uruchamianie procesu producenta i przekazywanie
        perror("prod fork error");                                                       //nazwy producenta,nazwy konsumenta,nazwy obszaru pamieci dzielonej, pliku wejscia, pliku wyjscia
        exit(EXIT_FAILURE); //zabezpieczenie execl
        break;

        default:
        break;
    }

    switch(kons_fork=fork())
    {
        case -1:
        perror("fork error");
        exit(EXIT_FAILURE);
        break;

        case 0:
        execl("./konsument.x","konsument.x",SEM_PROD,SEM_KONS,SHM_NAME,IN_FILE,OUT_FILE,NULL); //uruchamianie procesu konsumenta, parametry j.w
        perror("kons fork error");
        exit(EXIT_FAILURE);
        break;

        default:
        break;
    }

    if((wait(NULL))==-1)
    {
        perror("wait error");
        exit(EXIT_FAILURE);
    }
    if((wait(NULL))==-1)//czekanie na procesy potomnie
    {
        perror("wait error");
        exit(EXIT_FAILURE);
    }
    

    S_Remove(SEM_PROD); //usuwanie semaforow
    S_Remove(SEM_KONS);

    Sharmem_close(shar_mem_fd); //zamykanie obszaru pamieci dzielonej
    Sharmem_remove(SHM_NAME); //usuwanie obszaru pamieci dzielonej


    return 0;
}