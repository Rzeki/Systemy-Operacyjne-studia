#ifndef SHAR_MEM
#define SHAR_MEM


#include <stdio.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <sys/ipc.h>
#include <sys/wait.h>

#define NELE 20
#define NBUF 5
#define SHM_NAME "/sharmem" //nazwa obszaru pamieci dzielonej
#define IN_FILE "input.txt" //plik z ktorego czyta producent
#define OUT_FILE "output.txt" //plik do ktorego zapisuje konsument

//segment pamieci dzielonej
typedef struct
{
    char bufor[NBUF][NELE];
    int wstaw, wyjmij;
} SegmentPD;

int Sharmem_create(const char* name, int size); //typ int bo zwara deskryptor
int Sharmem_open(const char* name); //otwarcie obszaru pamieci dzielonej
void Sharmem_remove(const char* name); //usuniecie obszaru pamieci dzielonej
void *Sharmem_map(int fd, int size); //mapowanie stworzonego obszaru pamieci dzielonej
void Sharmem_unmap(void *addr, int size); //unmapowanie stworzonego obszaru pamieci dzielonej
void Sharmem_close(int fd); // zamkniecie obszaru pamieci dzielonej

#endif