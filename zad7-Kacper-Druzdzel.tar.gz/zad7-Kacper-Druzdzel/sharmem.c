#include "sharmem.h"



int Sharmem_create(const char* name, int size)
{
    int deskr;
    
    deskr = shm_open(name, O_RDWR | O_CREAT | O_EXCL , 0666);
    if(deskr==-1)
    {
        perror("Blad shm_open()");
        exit(EXIT_FAILURE);
    }
    if(ftruncate(deskr,size)==-1)
    {
        perror("Blad ftruncate()");
        exit(EXIT_FAILURE);
    }
    printf("obszar pamieci dzielonej zostal utworzony, adres: %p \n",deskr);
    return deskr;
}

int Sharmem_open(const char* name)
{
    int deskr;
    deskr = shm_open(name, O_RDWR, 0666);
    if(deskr==-1)
    {
        perror("shm_open error");
        exit(EXIT_FAILURE);
    }
    printf("pamiec dzielona zostala otwarta\n");
    return deskr;
}

void Sharmem_remove(const char* name)
{
    if((shm_unlink(name))==-1)
    {
        perror("shm_unlink error");
    }
    printf("Usunieto obszar pamieci dzielonej\n");
}

void *Sharmem_map(int fd, int size)
{
    void* result;
    if((result=mmap(NULL,size,PROT_READ | PROT_WRITE,MAP_SHARED,fd,0))==MAP_FAILED)
    {
        perror("mmap() error");
        exit(EXIT_FAILURE);
    }
    else
    {
        printf("zmapowano pamiec\n");
    }

    return result;
}

void Sharmem_unmap(void *addr, int size)
{
    int deskr;
    deskr=munmap(addr,size);
    if(deskr==-1)
    {
        perror("munmap() error");
        exit(EXIT_FAILURE);
    }
}

void Sharmem_close(int fd)
{
    int deskr;
    deskr=close(fd);
    if(deskr==-1)
    {
        perror("close() error");
        exit(EXIT_FAILURE);
    }
}