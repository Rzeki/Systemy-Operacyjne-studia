#include "semafor.h"
#include <semaphore.h>
#include <stdlib.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <unistd.h>
#include <sys/wait.h>

//--------------------------------------------------------------------------------------------------------------
//Semafory (z cwiczenia 6)
//--------------------------------------------------------------------------------------------------------------
sem_t *S_Create(const char *S_name, int value)
{
    sem_t *S;
    S = sem_open(S_name, O_CREAT | O_EXCL , 0666, value);  //tworzenie semafora z wartoscia value
    if(S==SEM_FAILED)
    {
        perror("Semafor juz istnieje\n");
        exit(EXIT_FAILURE);
    }
    printf("Semafor zostal utworzony, adres: %p \n",S);
    return S;
}

sem_t *S_Open(const char *S_name)
{
    sem_t *S;
    S = sem_open(S_name,O_CREAT,0666);  //otworzenie semafora
    if(S==SEM_FAILED)
    {
        perror("sem_open error");
        exit(EXIT_FAILURE);
    }
    if((write(1,"Semafor zostal otwarty\n",24))==-1)
    {
        perror("write() error"); //zabezpieczenie write
        exit(EXIT_FAILURE);
    }
    return S;
}

void S_Remove(const char *S_name)   //usuniecie semafora
{
    if((sem_unlink(S_name))==-1)
    {
        perror("sem_unlink error");
        exit(EXIT_FAILURE);
    }
    if((write(1,"Semafor zostal usuniety\n",25))==-1)
    {
        perror("write() error"); //zabezpieczenie write
        exit(EXIT_FAILURE);
    }
}

void S_V(sem_t *S)   //podniesienie semafora
{
    if((sem_post(S))==-1)
    {
        perror("Blad zwolnienia semafora");
        exit(EXIT_FAILURE);
    }
    if((write(1,"Semafor zostal podniesiony\n",28))==-1)
    {
        perror("write() error"); //zabezpieczenie write
        exit(EXIT_FAILURE);
    }
}

void S_P(sem_t *S)  //opuszczenie semafora
{
    if((sem_wait(S))==-1)
    {
        perror("Blad zajecia semafora");
        exit(EXIT_FAILURE);
    }
    if((write(1,"Semafor zostal opuszczony\n",27))==-1)
    {
        perror("write() error"); //zabezpieczenie write
        exit(EXIT_FAILURE);
    }
}

void S_Close(sem_t *S)  //zamkniecie semafora
{
    if((sem_close(S))==-1)
    {
        perror("Blad przy zamknieciu semafora");
        exit(EXIT_FAILURE);
    }
    if((write(1,"Zamknieto semafor\n",19))==-1)
    {
        perror("write() error"); //zabezpieczenie write
        exit(EXIT_FAILURE);
    }
}

void S_Info_P(sem_t *S)  // wartosc semafora producenta
{
    int value;
    char buff[10];
    if((sem_getvalue(S,&value))==-1)
    {
        perror("blad sem_getvalue");
        exit(EXIT_FAILURE);
    }
    if((sprintf(buff,"%d",value))<0)
    {
        perror("sprintf() error"); //zabezpieczenie sprintf
        exit(EXIT_FAILURE);
    }
    if((write(1,"wartosc semafora producenta: ",29))==-1)
    {
        perror("write() error"); //zabezpieczenie write
        exit(EXIT_FAILURE);
    }
    if((write(1,buff,ile_cyfr(value)))==-1)
    {
        perror("write() error"); //zabezpieczenie write
        exit(EXIT_FAILURE);
    }
    if((write(1,"\n",2))==-1)
    {
        perror("write() error"); //zabezpieczenie write
        exit(EXIT_FAILURE);
    }
}

void S_Info_K(sem_t *S)  // wartosc semafora konsumenta
{
    int value;
    char buff[10];
    if((sem_getvalue(S,&value))==-1)
    {
        perror("blad sem_getvalue");
        exit(EXIT_FAILURE);
    }
    if((sprintf(buff,"%d",value))<0)
    {
        perror("sprintf() error"); //zabezpieczenie sprintf
        exit(EXIT_FAILURE);
    }
    if((write(1,"wartosc semafora konsumenta: ",29))==-1)
    {
        perror("write() error"); //zabezpieczenie write
        exit(EXIT_FAILURE);
    }
    if((write(1,buff,ile_cyfr(value)))==-1)
    {
        perror("write() error"); //zabezpieczenie write
        exit(EXIT_FAILURE);
    }
    if((write(1,"\n",2))==-1)
    {
        perror("write() error"); //zabezpieczenie write
        exit(EXIT_FAILURE);
    }
}

int ile_cyfr(int a)
{
    if(a==0)
    {
       return 1; //funkcja ta jest glownie uzywana w sprintf w miescu ilosci wyswietlanych bajtow dlatego gdyby pojawilo sie 0 zostanie ono wyswietlone
    }
    int c=0;
    while(a!=0)
    {                  //funkcja ktora zlicza ilosc cyfr w liczbie (jeszcze jako int)
        c++;
        a/=10;
    }
    return c;
}

//-------------------------------------------------------------------------------------------------------------------------------------
//Pamiec dzielona
//-------------------------------------------------------------------------------------------------------------------------------------
