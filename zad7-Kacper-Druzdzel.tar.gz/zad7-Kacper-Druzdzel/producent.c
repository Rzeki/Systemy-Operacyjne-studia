#include "semafor.h"
#include "sharmem.h"

void p()
{
    if((write(1,"producent: ",12))==-1)
    {
        perror("write error");
        exit(EXIT_FAILURE);
    } //funkcja ktora pokazuje ze komunikat pochodzi od producenta
}

int main(int argc, char* argv[])
{
    sem_t *PROD;  //zmienna przechowujaca deskryptor semafora producenta
    sem_t *KONS; //zmienna przechowujaca deskryptor semafora konsumenta
    int bufsize;  //zmienna przetrzymujaca ilosc czytanych znakow z pliku input.txt
    char bufor1[NELE]; //bufor do ktorego zapisywany jest ciag znakow
    SegmentPD *wpd; //deklaracja segmentu pamieci dzielonej
    p();PROD=S_Open(argv[1]); //otworzenie semafora producenta (argv[1]= nazwa semafora producenta)
    p();KONS=S_Open(argv[2]); //otworzenie semafora konsumenta (argv[2]= nazwa semafora konsumenta)
    p();int sharmemfdprod = Sharmem_open(argv[3]); //deksryptor otwartego obszaru pamieci
    p();int in = open(argv[4],O_RDONLY,0666); //otworzenie pliku tekstowego input.txt
    if(in==-1)
    {
        perror("open error"); //zabezpieczenie open()
        exit(EXIT_FAILURE);
    }
    else
    {
        printf("plik %s zostal otwarty\n",argv[4]);
    }

    p(); wpd = (SegmentPD*) Sharmem_map(sharmemfdprod, sizeof(SegmentPD)); //mapowanie 

    while((bufsize=read(in,bufor1,NELE))!=0) //czyta do momentu aż nie będzie nic w pliku
    {
        if(bufsize==-1)
        {
            perror("read() error"); //zabezpieczenie read()
            exit(EXIT_FAILURE);
        }
        S_Info_P(PROD); //wartosc semafora producenta
        S_P(PROD); //opuszczenie semafora producenta
        S_Info_P(PROD);
        if(wpd->wstaw==NBUF)  //limit bufora
        {
            wpd->wstaw=0;
        }
        strcpy(wpd->bufor[wpd->wstaw],bufor1); //kopiowanie z bufora do pamieci dzielonej
        for(int i=0;i<=bufsize;i++)
        {
            wpd->bufor[wpd->wstaw][i]=bufor1[i];
            printf("%c",wpd->bufor[wpd->wstaw][i]);
        }
        printf(" - Porcja danych wyslana przez producenta, liczba znakow: %d\n",bufsize);
        wpd->wstaw = (wpd->wstaw + 1) % NBUF; //zwiekszanie wskaźnika o 1
        S_Info_K(KONS); //wartosc semafora konsumenta
        S_V(KONS);
        S_Info_K(KONS);
    }
    p();Sharmem_unmap(wpd,sizeof(SegmentPD)); //unmapowanie obszaru pamieci dzielonej
    p();S_Close(KONS); //zamykanie semaforow
    p();S_Close(PROD);
    p();Sharmem_close(sharmemfdprod); //zamykanie pamieci dzielonej
    p();
    if((close(in))==-1) //zamykanie pliku input.txt
    {
        perror("close() error");
        exit(EXIT_FAILURE);
    }

    return 0;
}




