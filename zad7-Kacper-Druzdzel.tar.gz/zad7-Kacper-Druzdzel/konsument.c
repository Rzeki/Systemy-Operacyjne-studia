#include "semafor.h"
#include "sharmem.h"


void k()
{
    if((write(1,"konsument: ",12))==-1)
    {
        perror("write error");
        exit(EXIT_FAILURE);
    } //funkcja ktora pokazuje ze komunikat pochodzi od konsumenta
}

int main(int argc, char* argv[])
{   
    int ile_znakow=0; //ile znakow odebral konsument
    char koniec='\0';
    sem_t *PROD;
    sem_t *KONS;
    SegmentPD *wpd;
    char bufor_znak; //do pliku output.txt bedziemy wpisywac ta zmienna znak po znaku
    k(); PROD=S_Open(argv[1]); //otworzenie semafora producenta
    k(); KONS=S_Open(argv[2]); //otworzenie semafora konsumenta
    k(); int sharmemfdkons = Sharmem_open(argv[3]); //otworzenie obszaru pamieci dzielonej
    int out = open(argv[5],O_WRONLY | O_CREAT,0666); //otworzenie pliku wyjscia (output.txt)
    if(out==-1)
    {
        perror("open error"); //zabezpieczenie open()
        exit(EXIT_FAILURE);
    }
    else
    {
        k(); printf("plik %s zostal otwarty/stworzony\n",argv[5]);
    }

    k(); wpd = (SegmentPD*) Sharmem_map(sharmemfdkons,sizeof(SegmentPD));

    while(bufor_znak!='0') //wpisuje do czasu az napotka 0
    {
        S_Info_K(KONS); //wartosc semafora konsumenta
        S_P(KONS);
        S_Info_K(KONS);
        for(int i=0;i<NELE;i++)
        {
            bufor_znak=wpd->bufor[wpd->wyjmij][i]; //przypisanie do bufora pojedynczego znaku
            if(write(out,&bufor_znak,1)==-1) //wpisywanie do pliku
            {
                perror("write() error");
                exit(EXIT_FAILURE);
            }
            ile_znakow++;
            printf("%c",bufor_znak); //wyswietlanie znakow
            if(bufor_znak=='0') //gdy napotka 0 konsument konczy prace
            {
                i++;
                bufor_znak=wpd->bufor[wpd->wyjmij][i]; //ostatnia iteracja, aby dodac znak konca linii
                if(write(out,&bufor_znak,1)==-1) //wpisywanie do pliku
                {
                    perror("write() error");
                    exit(EXIT_FAILURE);
                }
                ile_znakow++; //dodawanie znaku konca linii nizej w kodzie
                bufor_znak='0'; //wartosc ponownie ustawiana na 0, aby petla while mogla sie zakonczyc
                break;
            }
        }
        printf(" - Porcja danych odebrana przez konsumenta,liczba znakow: %d\n",ile_znakow);
        ile_znakow=0;
        wpd->wyjmij = (wpd->wyjmij + 1) % NBUF;
        if(wpd->wyjmij==NBUF)
        {
            wpd->wyjmij=0;
        }
        S_Info_P(PROD); //wartosc semafora producenta
        S_V(PROD);
        S_Info_P(PROD);
    }

    k(); Sharmem_unmap(wpd, sizeof(SegmentPD)); //unmapowanie obszaru pamieci dzielonej
    k(); S_Close(KONS); //zamkniecie semaforow
    k(); S_Close(PROD);
    k(); Sharmem_close(sharmemfdkons); //zamkniecie obszaru pamieci dzielonej
    k(); 
    if((close(out))==-1) //zamkniecie pliku wyjscia
    {
        perror("close() error");
        exit(EXIT_FAILURE);
    }


    return 0;
}
