#include <stdio.h>
#include <signal.h> //potrzebne do obslugi sygnalow
#include <ctype.h> //potrzebne do isdigit()
#include <stdlib.h> //potrzebne do exit() i atoi()
#include <unistd.h> //potrzebne do pause()
#include <sys/types.h> //potrzebne do kill()

extern const char * const sys_siglist[];  //deklaracja tablicy nazw sygnalow globalnie

void handler_capture(int sig)
{
    printf("\nPrzechwycono sygnal %s o numerze: %d\n\n",sys_siglist[sig],sig);    //funkcja ktora wykonuje sie po przechwyceniu sygnalu wyswietla nazwe oraz numer sygnalu
    exit(0);
}

int main(int argc, char* argv[])
{
    if(argc !=3)
    {
        perror("Niewlasciwa liczba argumentow!");     //sprawdzam czy zostala podana prawidlowa liczba argumentow, jesli nie program konczy prace
        exit(EXIT_FAILURE);
    }
    int num = atoi(argv[2]);   //konwersja drugiego argumentu na liczbę
    char c = *argv[1];         //konwersja pierwszego parametru na char
    if(num<=0 || num>=65)
    {
        perror("nieprawidlowy kod sygnalu");             //sprawdzam czy drugi argument jest liczbą z zakresu 1-64 (numery sygnalow pozyskane za pomoca kill -l)
        exit(EXIT_FAILURE);
    }
    
    printf("PID procesu: %d\n",getpid());     //wypisanie PID procesu
    printf("PID lidera: %d\n",getpgid(getpid())); //wypisane PID lidera (potrzebne w podpunkcie C)
    switch(c)
    {
        case 'i': //ignore - ignorowanie wysylanego sygnalu
        if(num==19 || num==9)
        {
            perror("\nTych sygnalow nie mozna zignorowac");   //Chodzi o SIG_STOP i SIG_KILL
            exit(EXIT_FAILURE);
        }
        if(signal(num,SIG_IGN)==SIG_ERR)   // ignorowanie sygnalu     
        {
            perror("Funkcja ma problem z podanym sygnalem");  //Jezeli funkcja signal() zwroci blad nastepuje zakonczenie programu
            exit(EXIT_FAILURE);
        }
        printf("sygnal %s o numerze %d bedzie ignorowany\n\n",sys_siglist[num],num);  //jezeli nie ma zadnych bledow nastepuje wykonanie funkcji signal oraz wyswietlenie komunikatu             
        break;

        case 'c':  //capture - przechwycenie sygnalu i wykonanie funkcji handler_capture()
            if(num==19 || num==9)
            {
                perror("\nTych sygnalow nie mozna przechwycic"); //j.w
                exit(EXIT_FAILURE);
            }
            if(signal(num,handler_capture)==SIG_ERR)    //przechwycenie sygnalu za pomoca zdefiniowanej wyzej funkcji
            {
                perror("Funkcja ma problem z podanym sygnalem"); //j.w
                exit(EXIT_FAILURE);
            } 
        break;

        case 'd':  //default - domyslne obsluzenie sygnalu (nic nie wypisuje)
            if(signal(num,SIG_DFL)==SIG_ERR)   //sygnal wykonywany domyslnie
            {
                perror("Funkcja ma problem z podanym sygnalem");  //j.w
                exit(EXIT_FAILURE);
            }
            printf("sygnal %s o numerze %d zostanie wykonany domyslnie\n\n",sys_siglist[num],num); //wyswietlenie komunikatu    
            break;

        default:
            perror("\nNieprawidlowy argument - dostepne argumenty: i, c, d\n");   //gdy wpisany zostanie zly argument program wypisuje dostepne argumenty i konczy prace
            exit(EXIT_FAILURE);
            break;
    }
    printf("\n");
    pause();   //oczekiwanie na sygnal
}