#include <stdio.h> 
#include <stdlib.h>  //potrzebne do funkcji exit()
#include <sys/types.h> 
#include <unistd.h> 
#include <sys/wait.h>
#include <signal.h>

extern const char * const sys_siglist[];  //deklaracja tablicy nazw sygnalow globalnie

int main(int argc, char* argv[])
{
    //sprawdzenie argumentow nastapilo w podC.c, jezeli jest blad ten program nie zostanie uruchomiony
    int num = atoi(argv[2]);   //konwersja drugiego argumentu na liczbę
    char c = *argv[1];         //konwersja pierwszego parametru na char
    if(signal(num,SIG_IGN)==SIG_ERR)   // ignorowanie sygnalu     
    {
        perror("Funkcja ma problem z podanym sygnalem");  //Jezeli funkcja signal() zwroci blad nastepuje zakonczenie programu
        exit(EXIT_FAILURE);
    } 
    printf("Proces lider - PID: %d\n\n",getpid()); //PID procesu lidera
    printf("sygnal %s o numerze %d bedzie ignorowany w procesie liderze\n",sys_siglist[num],num); //ignorowanie sygnalu nadeslanego przez proces macierzysty
    printf("Proces o PID: %d staje sie nowym liderem\n\n",getpid());
    if(setpgid(0,0)==-1)
    {
        perror("nie udalo sie ustawic lidera"); //ustawienie obecnego procesu jako lidera razem z zabezpieczeniem bledu setpgid()
        exit(EXIT_FAILURE);
    } 
    printf("PID lidera teraz: %d\n\n",getpgid(getpid())); //sprawdzenie 
    int i;
    for(i=0;i<3;i++)
    {
       switch(fork())
        {
            case -1:
                perror("fork error"); //zabezpieczenie bledu fork()
                exit(EXIT_FAILURE);
            break;
            case 0:
                sleep(i+1); //uzywam tego by wyswietlic procesy po kolei
                execv("podA.x",argv); //wywolanie programu z podpunktu a)
                perror("exec zwrocil blad"); //zabezpieczenie przed bledem execv
                exit(EXIT_FAILURE);
            break;
            default:
            break;
        } 
    }
    int j;
    for(j=0;j<3;j++)
    {
        wait(NULL); //oczekiwanie na zakonczenie wszystkich procesow potomnych lidera
    }
    return 0;
}