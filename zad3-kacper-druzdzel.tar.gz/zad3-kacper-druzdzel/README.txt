Szanowny Panie Profesorze,
Oddaje zadania: podA.c, podB.c, podC.c, podCv2.c (potrzebny w podC.c) oraz Makefile

Opis zadan:
podA.c:
Najpierw nastepuje sprawdzenie czy uzytkownik poprawnie wprowadza argumenty:
./podA.x X Y

X- mozemy wstawic "i" jezeli chcemy zeby program ignorowal podany sygnal, "c" jezeli chcemy zeby przechwycil sygnal i wykonal funkcje wlasna oraz "d" zeby sygnal zostal obsluzony domyslnie

Y- ma byc numerem z zakresu 1-64 (tyle ile numerow sygnalow - sprawdzone za pomoca kill -l) oczywiscie w programie wszystko jest zabezpieczone co do wprowadzania

w programie uzywam funkcji pause(), ktora pozwala na "nasluchiwanie" wysylanych sygnalow

---------------------------------Powyzsze instrukcje tycza sie wszystkich podpunktow-------------------------------------  

podB.c:
Uruchamia on program z podpunktu a), przy wczesniejszym sprawdzeniu argumentow (ponownie, bo uzywam execv) wiec jezeli argumenty sa zle podane, program nie wykonuje
nawet funkcji execv. Z procesu macierzystego wysylany jest sygnal do procesu dziecka z podanym numerem.

podC.c:
Tak samo jak w poprzednich programach, najpierw nastepuje sprawdzenie argumentow na tej samej zasadzie jak poprzednio (w podCv2.c nie uwzglednialem sprawdzania argumentow, poniewaz ten program nawet sie nie wykona gdy cos bedzie zle z argumentami, wiec mamy pewnosc ze do podCv2.c przekazywane sa odpowiednie argumenty)
w obecnym programie tworzony jest pojedynczy proces potomny w ktorym za pomoca execv uruchamiany jest podCv2.c, ktory ignoruje sygnal zdefiniowany w parametrze, staje sie liderem grupy oraz tworzy 3 potomne procesy (uzywajac funkcji fork() w petli 3 razy mam pewnosc ze dostane 3 procesy potomne, gdyz uzywam execv) ktore wykonuja program z podpunktu a) a nastepnie program czeka na zakonczenie procesow potomnych i konczy swoja prace, na co czekal program macierzysty zeby zakonczyc swoja prace.



Makefile:
dostepne komendy:
make all -- tworzy %.x wszystkich podpunktow
make clean -- usuwa pliki binarne
make tar -- kompresuje caly katalog

Przykladowe wywolania:
make runAc2 -- wywoluje ./podA.x c 2    (c poniewaz wyswietla komunikat i widac ze dziala)
make runBc2 -- wysoluje ./podB.x c 2    
make runCc2 -- wywoluje ./podC.x c 2

z powazaniem i zyczeniami zdrowia,
Kacper Druzdzel
