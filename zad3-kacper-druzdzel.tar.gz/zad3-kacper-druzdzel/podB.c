#include <stdio.h> 
#include <stdlib.h>  //potrzebne do funkcji exit()
#include <sys/types.h> 
#include <unistd.h> 
#include <errno.h> //potrzebne do sprawdzenia czy proces istnieje za pomoca kill()
#include <signal.h>

int child_pid;
extern const char * const sys_siglist[];  //deklaracja tablicy nazw sygnalow globalnie

int main(int argc, char* argv[])
{
    if(argc !=3)
    {
        perror("Niewlasciwa liczba argumentow!");     //sprawdzam czy zostala podana prawidlowa liczba argumentow, jesli nie program konczy prace
        exit(EXIT_FAILURE);
    }
    int num = atoi(argv[2]);   //konwersja drugiego argumentu na liczbę
    char c = *argv[1];         //konwersja pierwszego parametru na char
    switch(c)
    {
        case 'i':
        if(num==9 || num==19)
        {
            perror("Nie mozna zignorowac tego sygnalu");
            exit(EXIT_FAILURE);
        }
        break;
        case 'c':           //sprawdzanie za pomoca if() wyrzuca bledy wiec uzylem switcha w takej formie dla pewnosci poprawnego dzialania
        if(num==9 || num==19)  //zabezpieczylem przypadki w ktorych probujemy przechwycic/zignorowac SIGSTOP oraz SIGKILL
        {
            perror("Nie mozna przechwycic tego sygnalu");
            exit(EXIT_FAILURE);
        }
        break;
        case 'd':
        break;
        default:
        perror("\nNieprawidlowy argument - dostepne argumenty: i, c, d\n");   //gdy wpisany zostanie zly argument program wypisuje dostepne argumenty i konczy prace
        exit(EXIT_FAILURE);
        break;
    }
    if(num<=0 || num>=65)
    {
        perror("nieprawidlowy kod sygnalu");             //sprawdzam czy drugi argument jest liczbą z zakresu 1-64 (numery sygnalow pozyskane za pomoca kill -l)
        exit(EXIT_FAILURE);
    }
    printf("Proces macierzysty - PID: %d\n\n",getpid());
       switch (fork())
        {
            case -1:
                perror("FORK ERROR");  //gdyby fork() sie nie powiodl
                exit(EXIT_FAILURE);
            break;
            case 0:
                child_pid=getpid();
                printf("Proces dziecko - PID: %d\n\n",child_pid);
                execv("podA.x",argv);   
                perror("fork error"); 
                exit(EXIT_FAILURE);
            break;
            default:
            sleep(1);
            printf("Proces macierzysty - sprawdzam czy proces dziecko istnieje\n");
            kill(child_pid,0);
            if(errno == ESRCH)
            {
                perror("Dany proces nie istnieje!");
                exit(EXIT_FAILURE);
            }
            else
            {
                printf("Proces macierzysty - Znaleziono proces!\n");
                sleep(1);
                kill(child_pid,num);
                if(errno == ESRCH)
                {
                    perror("blad funkcji kill");
                    exit(EXIT_FAILURE);
                }
            }
            break;       
        };
    return 0;
}