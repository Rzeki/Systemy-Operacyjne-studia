#include <stdio.h> 
#include <stdlib.h>  //potrzebne do funkcji exit()
#include <sys/types.h> 
#include <unistd.h> 
#include <sys/wait.h>
#include <signal.h>
#include <errno.h>

int mac_pid,lider_pid;

extern const char * const sys_siglist[];  //deklaracja tablicy nazw sygnalow globalnie

int main(int argc, char* argv[])
{
    if(argc !=3)
    {
        perror("Niewlasciwa liczba argumentow!");     //sprawdzam czy zostala podana prawidlowa liczba argumentow, jesli nie program konczy prace
        exit(EXIT_FAILURE);
    }
    int num = atoi(argv[2]);   //konwersja drugiego argumentu na liczbę
    char c = *argv[1];         //konwersja pierwszego parametru na char
    switch(c)
    {
        case 'i':
        if(num==9 || num==19)
        {
            perror("Nie mozna zignorowac tego sygnalu");
            exit(EXIT_FAILURE);
        }
        break;
        case 'c':           //sprawdzanie za pomoca if() wyrzuca bledy wiec uzylem switcha w takej formie dla pewnosci poprawnego dzialania
        if(num==9 || num==19)  //zabezpieczylem przypadki w ktorych probujemy przechwycic/zignorowac SIGSTOP oraz SIGKILL
        {
            perror("Nie mozna przechwycic tego sygnalu");
            exit(EXIT_FAILURE);
        }
        break;
        case 'd':
        break;
        default:
        perror("\nNieprawidlowy argument - dostepne argumenty: i, c, d\n");   //gdy wpisany zostanie zly argument program wypisuje dostepne argumenty i konczy prace
        exit(EXIT_FAILURE);
        break;
    }
    if(num<=0 || num>=65)
    {
        perror("nieprawidlowy kod sygnalu");             //sprawdzam czy drugi argument jest liczbą z zakresu 1-64 (numery sygnalow pozyskane za pomoca kill -l)
        exit(EXIT_FAILURE);
    }
    mac_pid = getpid();
    printf("Proces macierzysty - PID: %d\n\n",mac_pid);
    switch(fork())
    {
        case -1:
            perror("fork error"); //zabezpieczenie przez bledem forka
            exit(EXIT_FAILURE);
        break;
        case 0:
            lider_pid=getpid(); 
            execv("podCv2.x",argv);   //wywolanie programu numer 2
            perror("exec zwrocil blad"); // zabezpieczenie przed bledem execv
            exit(EXIT_FAILURE);
        break;
        default:
            sleep(4);  //czekam az utworza sie procesy potomne w drugim programie
            printf("Sprawdzam czy proces lider istnieje\n");
            kill(lider_pid,0);   
            if(errno == ESRCH)
            {
                perror("proces nie istnieje\n"); //sprawdzenie czy proces lider istnieje, jezeli nie istnieje program konczy prace
                exit(EXIT_FAILURE);
            }
            printf("Proces lider istnieje!\n");
            printf("Proces macierzysty - wysylam sygnal %s o numerze %d do grupy procesow potomnych\n",sys_siglist[num],num);
            int m_lider_pid=(-1)*lider_pid;   //odpowiednio dla kill gdy pid<0 to sygnal wysylany jest do grupy procesow o PID lidera = -pid
            sleep(1);
            kill(m_lider_pid,num);
            if(errno == ESRCH)
            {
                perror("blad funkcji kill");
                exit(EXIT_FAILURE);
            }
            wait(NULL); //oczekiwanie na zakonczenie procesu-lidera
        break;
    }
    
    return 0;
}